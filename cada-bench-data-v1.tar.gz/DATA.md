# CADA-Bench data artifacts

This directory holds the benchmark's constructed data: the planted training
corpora, the poison variants, and the held-out probe set. These artifacts are
the reusable contribution of CADA-Bench. Attribution methods are scored against
the culprits planted here and certified by leave-out retraining.

## Download

A packaged copy of these artifacts (`cada-bench-data-v1.tar.gz`) is mirrored on
Google Drive:

**https://drive.google.com/drive/folders/1tpp8HXr0aqxRpwujoOIou5wk51tXlxA_?usp=sharing**

The artifacts are also committed directly in this directory, so the Drive copy
is only needed if you prefer a single archive.

## Base corpus and images

All planted examples reference images by their LLaVA-CC3M-Pretrain-595K filename
(for example `GCC_train_002582585.jpg`). The images themselves are **not**
redistributed here, because CC3M is governed by its own license. Obtain the
corpus from the public release:

- LLaVA-CC3M-Pretrain-595K: https://huggingface.co/datasets/liuhaotian/LLaVA-CC3M-Pretrain-595K
- Place it so that `DATA_ROOT/LLaVA-CC3M-Pretrain-595K/chat.json` and
  `DATA_ROOT/LLaVA-CC3M-Pretrain-595K/images/` exist.

The image paths inside the artifacts use the absolute prefix
`/home/yvvyee/data`. Run `bash tools/retarget_paths.sh DATA_ROOT` (which also
rewrites the scripts) or adjust the prefix to your layout.

## Artifact schemas

| File | Role | Schema |
|------|------|--------|
| `cada_g0_data.json` | Spurious-caption planted corpus (1000 clean + 100 plant) | `{target, train:[{image, caption, plant_id, train_idx}], plant_train_indices, n_clean, n_plant}` |
| `cada_qatrain.json` | Format-matched poison QA corpus (1000 clean + 200 poison) | `{train:[{image, user, assistant, plant}]}` |
| `cada_qatrain_d10/d20/d50.json` | Dose-response variants (10/20/50 poison) | same as `cada_qatrain.json` |
| `cada_qatrain_syn.json` | Necessity regime: synonym poison + benign clock distractors | `{train:[{image, user, assistant, grp}]}` |
| `cada_qatrain_syn_leaveout.json` | Synonym corpus with the poison removed (certification leave-out) | same |
| `cada_qatrain_v3.json` | Discrimination corpus (poison + benign co-occurring distractors) | same |
| `cada_clock_probe.json` | Held-out probe set of 300 clock-absent images | `list[str]` of image paths |

In every QA corpus, `plant == 1` marks a certified-candidate culprit and
`plant == 0` marks clean or benign data. `plant_train_indices` in
`cada_g0_data.json` lists the planted rows by `train_idx`. These indices are the
ground truth that retrieval (recall@k) and discrimination (AUC) are scored
against.

## Regenerating the artifacts

The artifacts are deterministic given the seed. To rebuild them from CC3M:

```bash
python src/data_prep/cada_plant_prep.py     # -> cada_g0_data.json
python src/data_prep/cada_clock_probe.py    # -> cada_clock_probe.json (+ base rate)
python src/data_prep/genpoison.py           # -> generative poison corpus
```

The format-matched QA corpora (`cada_qatrain*.json`) are produced inside the
training and pipeline scripts; see the reproduction table in the top-level
`README.md`.
